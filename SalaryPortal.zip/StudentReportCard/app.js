const btnAdd = document.getElementById("add");
const btnSearch = document.getElementById("search");
const btnDelete = document.getElementById("delete");
const btnUpdate = document.getElementById("update");
const btnGenerate = document.getElementById("generate");
let displayTxt = document.getElementById("display");
// alert("HEY");
let StudentList = [];

const add = () => {
  let listFound = JSON.parse(localStorage.getItem("student"));

  let name = document.getElementById("name").value;
  let rno = parseInt(document.getElementById("rno").value);
  let sci = parseInt(document.getElementById("sci").value);
  let math = parseInt(document.getElementById("math").value);
  let eng = parseInt(document.getElementById("eng").value);
  let hindi = parseInt(document.getElementById("hindi").value);
  let student = { rno, name, sci, math, eng, hindi };
  if (listFound == null) {
    StudentList = [...StudentList, student];
  } else {
    StudentList = listFound;
    StudentList = [...StudentList, student];
  }
  localStorage.setItem("student", JSON.stringify(StudentList));
  displayTxt.innerText = `EmployeeId ${rno} Added Sucessfully `;
};

const search = () => {
  let rno = parseInt(document.getElementById("rno").value);
  let studentFound = JSON.parse(localStorage.getItem("student"));

  if (studentFound == null) {
    displayTxt.innerText = "List Is Empty : ";
  } else {
    studentFound = studentFound.filter((curElm) => curElm.rno == rno);
  }
  return studentFound;
};

const deleteStudent = () => {
  let rno = document.getElementById("rno").value;
  let studentFound = JSON.parse(localStorage.getItem("student"));
  let searchFound = search(); //returns empty [] if not found
  if (searchFound.length != 0) {
    StudentList = studentFound.filter((curElm) => curElm.rno != rno);
    localStorage.setItem("student", JSON.stringify(StudentList));
    displayTxt.innerText = `EmployeeId: ${rno} Deleted ! `;
  } else {
    if (search().length == 0) {
      displayTxt.innerText = `EmployeeId: ${rno} not Found `;
    }
  }
};

const update = () => {
  let rno = document.getElementById("rno").value;
  let studentFound = search(); //returns empty [] if not found
  if (studentFound.length != 0) {
    deleteStudent();
    add();
  } else;
  {
    displayTxt.innerText = `EmployeeId : ${rno} not Found !`;
  }
};

const display = () => {
  let name = document.getElementById("name");
  let rno = document.getElementById("rno");
  let sci = document.getElementById("sci");
  let math = document.getElementById("math");
  let eng = document.getElementById("eng");
  let hindi = document.getElementById("hindi");

  let data = search(); //returns empty [] if not found
  if (data.length != 0) {
    name.value = data[0].name;
    rno.value = data[0].rno;
    sci.value = data[0].sci;
    math.value = data[0].math;
    eng.value = data[0].eng;
    hindi.value = data[0].hindi;
  } else {
    displayTxt.innerText = `Employee  not found`;
  }
};

const generateCard = () => {
  let rno = document.getElementById("rno").value;
  let studentFound = search();
  if (studentFound.length != 0) {
    localStorage.setItem("temp", JSON.stringify(studentFound));
    // location.href = "result.html";
    location.href = "Salary.html";
  } else {
    displayTxt.innerText = `Rollno : ${rno} Not Found !`;
  }
  //   console.log(studentFound);
};

btnAdd.addEventListener("click", () => {
  add();
});

btnSearch.addEventListener("click", () => {
  search();
  display();
});

btnDelete.addEventListener("click", () => {
  deleteStudent();
  // location.href = "salarySlip.html";
  // location.href = "Salary.html";
});

btnUpdate.addEventListener("click", () => {
  update();
});

btnGenerate.addEventListener("click", () => {
  generateCard();
});

function handleLogin() {
  let data = search();
  if (data.length != 0) {
    generateCard();
  } else {
    alert("employee not found");
  }
}
