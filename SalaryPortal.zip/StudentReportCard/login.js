function handleSignUp() {
  let empid = document.getElementById("empid").value;
  let email = document.getElementById("email").value;
  let password = document.getElementById("password").value;
  //  true
  if (empid === "101") {
    location.href = "index.html";
  } else {
    alert(empid + " Employee Not Found !");
  }

  console.log("password" == "password");

  // location.href = "index.html";
}
