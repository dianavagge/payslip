let rno = document.getElementById("trno");
let sname = document.getElementById("name");
let math = document.getElementById("math");
let sci = document.getElementById("sci");
let eng = document.getElementById("eng");
let hindi = document.getElementById("hindi");
let result = document.getElementById("tresult");
let percentage = document.getElementById("tpercentage");

let studentFound = JSON.parse(localStorage.getItem("temp"));

rno.innerText = studentFound[0].rno;
sname.innerText = studentFound[0].name;
math.innerText = studentFound[0].math;
sci.innerText = studentFound[0].sci;
eng.innerText = studentFound[0].eng;
hindi.innerText = studentFound[0].hindi;

let cal =
  studentFound[0].math +
  studentFound[0].sci +
  studentFound[0].eng +
  studentFound[0].hindi;

result.innerHTML = cal;
// cal = (cal / 400) * 100;
// percentage.innerText = cal;
// cal > 50 ? (result.innerText = "PASS") : (result.innerText = "FAIL");
